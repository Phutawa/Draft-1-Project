const mysql = require('mysql2/promise');

let pool = null;

async function getPool() {
    if (!pool) {
        try {
            pool = mysql.createPool({
                host: process.env.DB_HOST || 'localhost',
                user: process.env.DB_USER || 'root',
                password: process.env.DB_PASS || '',
                database: process.env.DB_NAME || 'clothing_admin',
                waitForConnections: true,
                connectionLimit: 10,
                queueLimit: 0
            });
            // Test connection
            await pool.query('SELECT 1');
            console.log('✅ MySQL connected');
        } catch (err) {
            console.log('⚠️  MySQL not available, using mock data');
            pool = null;
        }
    }
    return pool;
}

async function query(sql, params) {
    const p = await getPool();
    if (!p) return null;
    try {
        const [rows] = await p.execute(sql, params);
        return rows;
    } catch (err) {
        console.error('DB Error:', err.message);
        return null;
    }
}

module.exports = { getPool, query };
