const app = require('./app');
const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.log(`✨ Admin Panel running at http://localhost:${PORT}`);
    console.log(`   Login: http://localhost:${PORT}/auth/login`);
});
