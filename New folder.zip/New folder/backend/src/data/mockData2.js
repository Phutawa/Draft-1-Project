// Mock data Part 2: Orders, Receipts, Reviews, Chats, Kanban, Analytics
const orderStatuses = ['PENDING', 'CONFIRMED', 'SHIPPING', 'DELIVERED', 'CANCELLED'];

function generateOrders() {
    const customers = ['Sarah Jenkins', 'Michael Ross', 'Emily Blunt', 'Jonathan Doe', 'Alice Smith', 'Bob Jones', 'Charlie Day', 'Dana White', 'Evan Lee', 'Fiona Chen'];
    const orders = [];
    for (let i = 1; i <= 30; i++) {
        const status = orderStatuses[Math.floor(Math.random() * orderStatuses.length)];
        const itemCount = Math.floor(Math.random() * 5) + 1;
        const total = Math.floor(Math.random() * 300 + 30);
        orders.push({
            id: i, order_id: `#ORD-${55400 + i}`,
            customer_name: customers[i % customers.length],
            customer_email: customers[i % customers.length].toLowerCase().replace(' ', '.') + '@email.com',
            customer_avatar: customers[i % customers.length].charAt(0),
            items_count: itemCount, total: total, status: status,
            shipping_address: `${100 + i} Main St, Bangkok 10${100 + i}`,
            created_at: `Oct ${Math.floor(Math.random() * 28 + 1)}, 2025`,
            items: Array.from({ length: itemCount }, (_, j) => ({
                id: j + 1, product_name: `Product ${j + 1}`, sku: `PRD-${100 + j}`,
                quantity: Math.floor(Math.random() * 3 + 1), price: Math.floor(Math.random() * 100 + 20),
                size: ['S', 'M', 'L'][Math.floor(Math.random() * 3)], color: 'Beige'
            }))
        });
    }
    return orders;
}

function generateReceipts() {
    const receipts = [];
    for (let i = 1; i <= 12; i++) {
        receipts.push({
            id: i, receipt_number: `#REC-${9900 + i}`, order_id: i,
            order_number: `#ORD-${55400 + i}`,
            amount: Math.floor(Math.random() * 200 + 30),
            description: 'Monthly Subscription - Pro',
            status: i % 3 === 0 ? 'VOID' : 'PAID',
            created_at: `${['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][i - 1]} 12, 2025`,
            email_sent: i % 2 === 0, voided: i % 3 === 0
        });
    }
    return receipts;
}

function generateReviews() {
    const names = ['Sarah J.', 'Mike R.', 'Emily B.', 'John D.', 'Alice S.', 'Bob J.', 'Clara D.', 'Dan W.'];
    const comments = [
        'Absolutely love this! The fabric quality is amazing.',
        'Good fit but color slightly different from the photo.',
        'Perfect for summer, very comfortable material.',
        'Nice design but took a while to deliver.',
        'Excellent quality, will buy again!',
        'The stitching could be better at this price point.',
        'Beautiful piece, exactly as described.',
        'Runs a bit small, recommend sizing up.'
    ];
    return names.map((name, i) => ({
        id: i + 1, product_id: i + 1, product_name: `Product ${i + 1}`,
        customer_name: name, rating: Math.floor(Math.random() * 3 + 3),
        comment: comments[i], images: i % 3 === 0 ? ['review1.jpg'] : [],
        is_hidden: false, admin_reply: i % 4 === 0 ? 'Thank you for your feedback!' : null,
        likes: Math.floor(Math.random() * 20),
        created_at: `Oct ${10 + i}, 2025`
    }));
}

function generateChats() {
    return [
        {
            id: 1, customer_name: 'Sarah Jenkins', status: 'open', avatar: 'SJ', last_message: "I haven't received my tracking number yet.", updated_at: '10:45 AM',
            messages: [
                { id: 1, sender: 'customer', text: "Hi! I placed an order three days ago (Order #8291) but I still haven't received a tracking number in my email. Could you check the status for me?", time: '10:45 AM' },
                { id: 2, sender: 'admin', text: "Hello Sarah! I'd be happy to help you with that. Let me look into your order details right away.", time: '10:46 AM' },
                { id: 3, sender: 'admin', text: "I see your order. It's currently being processed at our warehouse and is scheduled to be picked up by the courier this afternoon.", time: '10:46 AM' },
                { id: 4, sender: 'customer', text: "Oh, that's great! I was worried it might have been delayed. Thank you so much for the quick response!", time: '10:47 AM' }
            ]
        },
        {
            id: 2, customer_name: 'Michael Chan', status: 'open', avatar: 'MC', last_message: 'Do you have this in size Large?', updated_at: '11:30 AM',
            messages: [
                { id: 1, sender: 'customer', text: 'Do you have this in size Large?', time: '11:30 AM' }
            ]
        },
        {
            id: 3, customer_name: 'Emma Watson', status: 'closed', avatar: 'EW', last_message: 'Thank you for the quick refund!', updated_at: 'Yesterday',
            messages: [
                { id: 1, sender: 'customer', text: 'Thank you for the quick refund!', time: 'Yesterday' }
            ]
        },
        {
            id: 4, customer_name: 'David Miller', status: 'open', avatar: 'DM', last_message: 'The blue jacket is out of stock.', updated_at: 'Oct 19',
            messages: [
                { id: 1, sender: 'customer', text: 'The blue jacket is out of stock.', time: 'Oct 19' }
            ]
        }
    ];
}

const kanbanBoards = [{
    id: 1, name: 'Sprint - March 2026',
    columns: [
        {
            id: 1, name: 'To Do', color: '#8F8272', tasks: [
                { id: 1, title: 'Design new collection page', description: 'Create wireframes for Spring 2026', assignee: 'Phutawan', priority: 'high', due: 'Mar 15', comments: 3 },
                { id: 2, title: 'Update product photos', description: 'Reshoot for new catalog', assignee: 'Somchai', priority: 'medium', due: 'Mar 20', comments: 1 }
            ]
        },
        {
            id: 2, name: 'In Progress', color: '#C8A77D', tasks: [
                { id: 3, title: 'Fix checkout flow', description: 'Address cart abandonment issues', assignee: 'Nattaya', priority: 'high', due: 'Mar 10', comments: 5 },
                { id: 4, title: 'Inventory audit', description: 'Q1 stock reconciliation', assignee: 'Phutawan', priority: 'low', due: 'Mar 25', comments: 0 }
            ]
        },
        {
            id: 3, name: 'Review', color: '#D7CDBE', tasks: [
                { id: 5, title: 'Email template redesign', description: 'New receipt email layout', assignee: 'Somchai', priority: 'medium', due: 'Mar 8', comments: 2 }
            ]
        },
        {
            id: 4, name: 'Done', color: '#4CAF50', tasks: [
                { id: 6, title: 'SSL Certificate renewal', description: 'Annual renewal completed', assignee: 'Nattaya', priority: 'high', due: 'Mar 1', comments: 1 }
            ]
        }
    ]
}];

const analyticsData = {
    revenue: { total: 284750, growth: 24, daily: [12000, 15000, 13500, 18000, 16500, 21000, 19500] },
    orders: { total: 2543, pending: 45, shipped: 892, delivered: 1606 },
    productsSold: 4280,
    topProducts: [
        { name: 'Silk Blouse', views: 2450, wishlists: 342, sales: 189 },
        { name: 'Linen Trousers', views: 1980, wishlists: 215, sales: 156 },
        { name: 'Cashmere Sweater', views: 1750, wishlists: 198, sales: 134 },
        { name: 'Summer Dress', views: 1620, wishlists: 156, sales: 121 },
        { name: 'Denim Jacket', views: 1490, wishlists: 96, sales: 98 }
    ],
    searchKeywords: [
        { keyword: 'silk blouse', count: 890 }, { keyword: 'summer dress', count: 756 },
        { keyword: 'linen pants', count: 634 }, { keyword: 'cashmere', count: 521 },
        { keyword: 'denim jacket', count: 445 }
    ],
    categoryPerformance: [
        { name: 'Women', revenue: 98500, orders: 856 },
        { name: 'Men', revenue: 76200, orders: 634 },
        { name: 'Kids', revenue: 34500, orders: 412 },
        { name: 'Recent', revenue: 42300, orders: 389 },
        { name: 'Collection', revenue: 33250, orders: 252 }
    ],
    recentActivity: [
        { type: 'order', text: 'New order #ORD-55430 from Sarah Jenkins', time: '2 min ago' },
        { type: 'review', text: 'New 5-star review on Silk Blouse', time: '15 min ago' },
        { type: 'product', text: 'Low stock alert: Cashmere Sweater (3 left)', time: '1 hr ago' },
        { type: 'order', text: 'Order #ORD-55428 marked as delivered', time: '2 hrs ago' },
        { type: 'chat', text: 'New message from Michael Chan', time: '3 hrs ago' }
    ],
    dailyLabels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    viewsTrend: [1200, 1800, 1500, 2100, 1900, 2400, 2200],
    conversionRate: 3.8,
    uniqueViewers: 12500,
    totalLikes: 8400
};

// Timeline / Roadmap Mock Data
const timelineCategories = ['Promotions', 'Restocks', 'Design', 'Marketing', 'Operations'];
const timelineCategoryColors = {
    'Promotions': '#C8A77D',
    'Restocks': '#8F8272',
    'Design': '#B89468',
    'Marketing': '#D7CDBE',
    'Operations': '#A0937D'
};

const timelineMilestones = [
    {
        id: 1,
        name: 'Summer Promo 2026',
        description: 'Complete summer promotion campaign from drafting to launch',
        category: 'Promotions',
        startWeek: 1,
        endWeek: 4,
        status: 'in-progress',
        phases: [
            { id: 1, name: 'DRAFTING PROMOTION', startWeek: 1, endWeek: 2, color: '#C8A77D', row: 0 },
            { id: 2, name: 'APPROVING PHASE', startWeek: 2, endWeek: 3, color: '#D7CDBE', row: 1 },
            { id: 3, name: 'ASSET GATHERING', startWeek: 3, endWeek: 3, color: '#E9DEC1', row: 2 },
            { id: 4, name: 'LAUNCHING', startWeek: 4, endWeek: 4, color: '#F5F2EB', row: 3 }
        ],
        tasks: [
            { id: 1, title: 'Summer Promo Draft', category: 'Promotions', assignee: 'Phutawan', priority: 'high', deadline: 'Mar 10', status: 'in-progress', row: 0 },
            { id: 2, title: 'Review & Approval', category: 'Marketing', assignee: 'Somchai', priority: 'medium', deadline: 'Mar 18', status: 'todo', row: 1 },
            { id: 3, title: 'Creative Production', category: 'Design', assignee: 'Nattaya', priority: 'high', deadline: 'Mar 22', status: 'todo', row: 2 },
            { id: 4, title: 'Channel Launch', category: 'Marketing', assignee: 'Phutawan', priority: 'high', deadline: 'Mar 28', status: 'todo', row: 3 },
            { id: 5, title: 'Performance Audit', category: 'Operations', assignee: 'Somchai', priority: 'medium', deadline: 'Mar 31', status: 'todo', row: 4 }
        ]
    },
    {
        id: 2,
        name: 'Q2 Restock Plan',
        description: 'Inventory replenishment and new stock arrivals for Q2',
        category: 'Restocks',
        startWeek: 1,
        endWeek: 4,
        status: 'planned',
        phases: [
            { id: 5, name: 'VENDOR NEGOTIATION', startWeek: 1, endWeek: 1, color: '#8F8272', row: 0 },
            { id: 6, name: 'ORDER PROCESSING', startWeek: 2, endWeek: 3, color: '#D7CDBE', row: 1 },
            { id: 7, name: 'QC & RECEIVING', startWeek: 3, endWeek: 4, color: '#C8A77D', row: 2 },
            { id: 8, name: 'SHELF PLACEMENT', startWeek: 4, endWeek: 4, color: '#E9DEC1', row: 3 }
        ],
        tasks: [
            { id: 6, title: 'Contact vendors', category: 'Operations', assignee: 'Nattaya', priority: 'high', deadline: 'Mar 7', status: 'completed', row: 0 },
            { id: 7, title: 'Place purchase orders', category: 'Restocks', assignee: 'Phutawan', priority: 'high', deadline: 'Mar 14', status: 'in-progress', row: 1 },
            { id: 8, title: 'Quality control check', category: 'Operations', assignee: 'Somchai', priority: 'medium', deadline: 'Mar 24', status: 'todo', row: 2 },
            { id: 9, title: 'Update product listings', category: 'Design', assignee: 'Nattaya', priority: 'low', deadline: 'Mar 28', status: 'todo', row: 3 }
        ]
    },
    {
        id: 3,
        name: 'Website Redesign Sprint',
        description: 'Redesign key pages for improved conversion rates',
        category: 'Design',
        startWeek: 1,
        endWeek: 4,
        status: 'in-progress',
        phases: [
            { id: 9, name: 'UI/UX RESEARCH', startWeek: 1, endWeek: 2, color: '#B89468', row: 0 },
            { id: 10, name: 'WIREFRAME & PROTOTYPE', startWeek: 2, endWeek: 3, color: '#C8A77D', row: 1 },
            { id: 11, name: 'DEVELOPMENT', startWeek: 3, endWeek: 4, color: '#8F8272', row: 2 }
        ],
        tasks: [
            { id: 10, title: 'User flow analysis', category: 'Design', assignee: 'Nattaya', priority: 'high', deadline: 'Mar 12', status: 'completed', row: 0 },
            { id: 11, title: 'Figma mockups', category: 'Design', assignee: 'Nattaya', priority: 'high', deadline: 'Mar 20', status: 'in-progress', row: 1 },
            { id: 12, title: 'Frontend implementation', category: 'Design', assignee: 'Phutawan', priority: 'medium', deadline: 'Mar 30', status: 'todo', row: 2 }
        ]
    }
];

const timelineAllTasks = timelineMilestones.flatMap(m => m.tasks.map(t => ({ ...t, milestone: m.name, milestoneId: m.id })));

const timelineStats = {
    operationalHealth: 92,
    healthTrend: '+4.1%',
    activeMilestones: 12,
    milestonesUrgent: 3,
    teamCapacity: 84
};

// Settings: Admin Profile Mock Data
const adminProfile = {
    fullName: 'Phutawan 037',
    email: 'phutawan@coreandco.com',
    phone: '+66 98 765 4321',
    avatar: 'P',
    role: 'Owner',
    storeName: 'Core & Co',
    taxId: '0-1234-56789-01-2',
    supportEmail: 'support@coreandco.com',
    registeredAddress: '123/45 Soi Sukhumvit 55, Klongton Nua, Wattana, Bangkok 10110, Thailand'
};

// Settings: System Alert Toggles
const systemAlerts = {
    orderAlerts: true,
    stockAlerts: false,
    paymentFailures: true
};

// Settings: Customer Messages Inbox
const customerMessages = [
    {
        id: 1,
        name: 'Jane Doe',
        avatar: 'JD',
        avatarColor: '#C8A77D',
        tag: 'Order',
        tagType: 'order',
        message: "I haven't received my tracking number for the linen blazer I ordered yesterday.",
        time: '3 hours ago'
    },
    {
        id: 2,
        name: 'Mark Richards',
        avatar: 'MR',
        avatarColor: '#8F8272',
        tag: 'General Inquiry',
        tagType: 'inquiry',
        message: 'Do you have plans to restock the Liquid Glass silk scarves in emerald green?',
        time: '5 hours ago'
    },
    {
        id: 3,
        name: 'Sarah Chen',
        avatar: 'SC',
        avatarColor: '#B89468',
        tag: 'Return Request',
        tagType: 'return',
        message: 'The size M runs a bit large, I would like to exchange it for a size S if possible.',
        time: 'Yesterday'
    }
];

const orders = generateOrders();
const receipts = generateReceipts();
const reviews = generateReviews();
const chats = generateChats();

module.exports = { orders, receipts, reviews, chats, kanbanBoards, analyticsData, orderStatuses, timelineMilestones, timelineAllTasks, timelineStats, timelineCategories, timelineCategoryColors, adminProfile, systemAlerts, customerMessages };
