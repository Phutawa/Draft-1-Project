// Mock data for admin panel - Part 1: Admins, Categories, Products
const admins = [
    { id: 1, username: 'owner_admin', email: 'owner@store.com', role: 'Owner', avatar: 'O', name: 'Phutawan 037' },
    { id: 2, username: 'manager1', email: 'manager@store.com', role: 'Manager', avatar: 'M', name: 'Somchai K.' },
    { id: 3, username: 'staff1', email: 'staff@store.com', role: 'Staff', avatar: 'S', name: 'Nattaya P.' }
];

const categories = [
    { id: 1, name: 'Women', name_th: 'หญิง', slug: 'women', parent_id: null, product_count: 15, icon: 'bi-gender-female' },
    { id: 2, name: 'Men', name_th: 'ผู้ชาย', slug: 'men', parent_id: null, product_count: 15, icon: 'bi-gender-male' },
    { id: 3, name: 'Kids', name_th: 'เด็กเล็ก', slug: 'kids', parent_id: null, product_count: 15, icon: 'bi-emoji-smile' },
    { id: 4, name: 'Recent', name_th: 'ล่าสุด', slug: 'recent', parent_id: null, product_count: 15, icon: 'bi-clock' },
    { id: 5, name: 'Collection', name_th: 'คอลเล็คชั่น', slug: 'collection', parent_id: null, product_count: 15, icon: 'bi-collection' },
    { id: 6, name: 'Dresses', name_th: 'เดรส', slug: 'dresses', parent_id: 1, product_count: 5, icon: 'bi-tag' },
    { id: 7, name: 'Tops', name_th: 'เสื้อ', slug: 'tops', parent_id: 1, product_count: 5, icon: 'bi-tag' },
    { id: 8, name: 'Shirts', name_th: 'เสื้อเชิ้ต', slug: 'shirts', parent_id: 2, product_count: 5, icon: 'bi-tag' },
    { id: 9, name: 'Pants', name_th: 'กางเกง', slug: 'pants', parent_id: 2, product_count: 5, icon: 'bi-tag' }
];

const statusList = ['active', 'draft', 'archived'];
const sizes = ['XS', 'S', 'M', 'L', 'XL'];
const colors = ['White', 'Black', 'Beige', 'Navy', 'Brown', 'Pink', 'Gray', 'Red'];

function generateProducts() {
    const items = [];
    const womenNames = ['Silk Blouse', 'Linen Dress', 'Cashmere Sweater', 'Summer Dress', 'Wrap Skirt', 'Knit Cardigan', 'Pleated Pants', 'Chiffon Top', 'Denim Jacket', 'Maxi Dress', 'Cotton Tee', 'Blazer', 'Wool Coat', 'Satin Camisole', 'Floral Midi Dress'];
    const menNames = ['Linen Trousers', 'Oxford Shirt', 'Polo Shirt', 'Chino Pants', 'Denim Jacket', 'Wool Blazer', 'Henley Tee', 'Cargo Shorts', 'Bomber Jacket', 'Slim Fit Jeans', 'V-Neck Sweater', 'Button Down', 'Parka Coat', 'Dress Shirt', 'Jogger Pants'];
    const kidsNames = ['Rainbow Tee', 'Denim Overalls', 'Floral Sundress', 'Cargo Shorts', 'Striped Polo', 'Tutu Skirt', 'Hoodie', 'Sweatpants', 'Puffer Vest', 'Graphic Tee', 'Corduroy Pants', 'Knit Beanie Set', 'Rain Jacket', 'Pajama Set', 'Cotton Romper'];
    const recentNames = ['Linen Blend Shirt', 'Oversized Blazer', 'Wide Leg Pants', 'Cropped Jacket', 'Ribbed Tank', 'Utility Vest', 'Pleated Midi', 'Mock Neck Top', 'Relaxed Fit Jean', 'Trench Coat', 'Satin Blouse', 'Knit Polo', 'Drawstring Shorts', 'Peplum Top', 'A-Line Skirt'];
    const collNames = ['Ethereal Gown', 'Golden Hour Blazer', 'Midnight Velvet Dress', 'Pearl Knit Set', 'Ivory Silk Blouse', 'Champagne Trousers', 'Rose Quartz Cardigan', 'Opal Linen Dress', 'Amber Wool Coat', 'Crystal Chiffon Top', 'Jade Wrap Dress', 'Ruby Evening Gown', 'Sapphire Blazer Set', 'Topaz Linen Suit', 'Diamond Silk Cami'];
    const allNames = [womenNames, menNames, kidsNames, recentNames, collNames];
    const catIds = [1, 2, 3, 4, 5];

    let id = 1;
    for (let c = 0; c < 5; c++) {
        for (let p = 0; p < 15; p++) {
            const price = Math.floor(Math.random() * 200 + 30);
            const hasDiscount = Math.random() > 0.6;
            items.push({
                id: id,
                category_id: catIds[c],
                category_name: categories[c].name,
                name: allNames[c][p],
                description: `Premium quality ${allNames[c][p].toLowerCase()} from our ${categories[c].name} collection.`,
                price: price,
                discount_price: hasDiscount ? Math.floor(price * 0.8) : null,
                sku: `SKU-${String(catIds[c]).padStart(2, '0')}-${String(id).padStart(4, '0')}`,
                stock: Math.floor(Math.random() * 100 + 5),
                status: statusList[Math.floor(Math.random() * 2)],
                thumbnail: null,
                wishlists: Math.floor(Math.random() * 400),
                views: Math.floor(Math.random() * 2000 + 100),
                created_at: `2025-${String(Math.floor(Math.random() * 12 + 1)).padStart(2, '0')}-${String(Math.floor(Math.random() * 28 + 1)).padStart(2, '0')}`,
                variants: sizes.slice(0, 3 + Math.floor(Math.random() * 3)).map(s => ({
                    size: s, color: colors[Math.floor(Math.random() * colors.length)], stock: Math.floor(Math.random() * 20 + 1)
                }))
            });
            id++;
        }
    }
    return items;
}

const products = generateProducts();

module.exports = { admins, categories, products, sizes, colors };
