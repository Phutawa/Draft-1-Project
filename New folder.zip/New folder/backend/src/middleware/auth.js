function requireAuth(req, res, next) {
    if (req.session && req.session.user) {
        return next();
    }
    req.flash('error', 'Please login to continue');
    res.redirect('/auth/login');
}

function requireRole(...roles) {
    return (req, res, next) => {
        if (!req.session || !req.session.user) {
            req.flash('error', 'Please login to continue');
            return res.redirect('/auth/login');
        }
        if (!roles.includes(req.session.user.role)) {
            req.flash('error', 'You do not have permission to access this page');
            return res.redirect('/dashboard');
        }
        next();
    };
}

module.exports = { requireAuth, requireRole };
