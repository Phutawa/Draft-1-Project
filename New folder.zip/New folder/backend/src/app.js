require('dotenv').config();
const express = require('express');
const expressLayouts = require('express-ejs-layouts');
const session = require('express-session');
const flash = require('connect-flash');
const path = require('path');

const app = express();

// View engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../../frontend/views'));
app.use(expressLayouts);
app.set('layout', 'layouts/main');

// Static files
app.use(express.static(path.join(__dirname, '../../frontend/public')));

// Body parsing
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Session
app.use(session({
    secret: process.env.SESSION_SECRET || 'default-secret',
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 24 * 60 * 60 * 1000 }
}));

// Flash messages
app.use(flash());

// Global variables for views
app.use((req, res, next) => {
    res.locals.success = req.flash('success');
    res.locals.error = req.flash('error');
    res.locals.user = req.session.user || null;
    res.locals.currentPath = req.path;
    next();
});

// Routes
const authRoutes = require('./routes/auth');
const dashboardRoutes = require('./routes/dashboard');
const productRoutes = require('./routes/products');
const categoryRoutes = require('./routes/categories');
const orderRoutes = require('./routes/orders');
const receiptRoutes = require('./routes/receipts');
const reviewRoutes = require('./routes/reviews');
const chatRoutes = require('./routes/chats');
const analyticsRoutes = require('./routes/analytics');
const kanbanRoutes = require('./routes/kanban');
const settingsRoutes = require('./routes/settings');

app.use('/auth', authRoutes);
app.use('/dashboard', dashboardRoutes);
app.use('/products', productRoutes);
app.use('/categories', categoryRoutes);
app.use('/orders', orderRoutes);
app.use('/receipts', receiptRoutes);
app.use('/reviews', reviewRoutes);
app.use('/chats', chatRoutes);
app.use('/analytics', analyticsRoutes);
app.use('/kanban', kanbanRoutes);
app.use('/settings', settingsRoutes);

// Root redirect
app.get('/', (req, res) => {
    if (req.session.user) {
        res.redirect('/dashboard');
    } else {
        res.redirect('/auth/login');
    }
});

// 404 handler
app.use((req, res) => {
    res.status(404).render('pages/error', {
        layout: 'layouts/auth',
        title: '404 - Not Found',
        code: 404,
        message: 'Page not found'
    });
});

// Error handler
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).render('pages/error', {
        layout: 'layouts/auth',
        title: '500 - Server Error',
        code: 500,
        message: 'Something went wrong'
    });
});

module.exports = app;
