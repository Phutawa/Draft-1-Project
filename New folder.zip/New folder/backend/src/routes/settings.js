const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const { adminProfile, systemAlerts, customerMessages } = require('../data/mockData2');

// Profile (default settings page)
router.get('/', requireAuth, (req, res) => {
    res.render('pages/settings/profile', { title: 'Profile', adminProfile });
});

// Security
router.get('/security', requireAuth, (req, res) => {
    res.render('pages/settings/index', { title: 'Security' });
});

// Notifications & Marketing Broadcast
router.get('/notifications', requireAuth, (req, res) => {
    res.render('pages/settings/notifications', {
        title: 'Notifications',
        systemAlerts,
        customerMessages
    });
});

// POST handlers
router.post('/profile/update', requireAuth, (req, res) => {
    req.flash('success', 'Profile updated successfully');
    res.redirect('/settings');
});

router.post('/password', requireAuth, (req, res) => {
    req.flash('success', 'Password updated successfully');
    res.redirect('/settings/security');
});

router.post('/notifications/alerts', requireAuth, (req, res) => {
    req.flash('success', 'Alert preferences updated');
    res.redirect('/settings/notifications');
});

router.post('/notifications/campaign', requireAuth, (req, res) => {
    req.flash('success', 'Campaign sent successfully!');
    res.redirect('/settings/notifications');
});

module.exports = router;
