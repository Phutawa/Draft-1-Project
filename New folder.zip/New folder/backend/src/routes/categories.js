const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const { categories } = require('../data/mockData');

router.get('/', requireAuth, (req, res) => {
    res.render('pages/categories/index', { title: 'Categories', categories });
});

router.post('/create', requireAuth, (req, res) => {
    req.flash('success', 'Category created successfully');
    res.redirect('/categories');
});

router.post('/edit/:id', requireAuth, (req, res) => {
    req.flash('success', 'Category updated successfully');
    res.redirect('/categories');
});

router.post('/delete/:id', requireAuth, (req, res) => {
    req.flash('success', 'Category deleted successfully');
    res.redirect('/categories');
});

module.exports = router;
