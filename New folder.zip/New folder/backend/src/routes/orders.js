const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const { orders, orderStatuses } = require('../data/mockData2');

router.get('/', requireAuth, (req, res) => {
    const { status, search } = req.query;
    let filtered = [...orders];
    if (status && status !== 'ALL') filtered = filtered.filter(o => o.status === status);
    if (search) filtered = filtered.filter(o => o.order_id.includes(search) || o.customer_name.toLowerCase().includes(search.toLowerCase()));
    res.render('pages/orders/index', { title: 'Orders', orders: filtered, orderStatuses, currentStatus: status || 'ALL', query: { search } });
});

router.get('/:id', requireAuth, (req, res) => {
    const order = orders.find(o => o.id == req.params.id);
    if (!order) return res.redirect('/orders');
    res.render('pages/orders/detail', { title: `Order ${order.order_id}`, order, orderStatuses });
});

router.post('/:id/status', requireAuth, (req, res) => {
    req.flash('success', 'Order status updated');
    res.redirect(`/orders/${req.params.id}`);
});

module.exports = router;
