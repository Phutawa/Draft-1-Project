const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const { receipts } = require('../data/mockData2');

router.get('/', requireAuth, (req, res) => {
    res.render('pages/receipts/index', { title: 'Receipts', receipts });
});

router.post('/:id/void', requireAuth, (req, res) => {
    req.flash('success', 'Receipt marked as void');
    res.redirect('/receipts');
});

router.post('/:id/resend', requireAuth, (req, res) => {
    req.flash('success', 'Receipt email resent');
    res.redirect('/receipts');
});

module.exports = router;
