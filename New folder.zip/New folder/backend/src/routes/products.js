const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const { products, categories } = require('../data/mockData');

router.get('/', requireAuth, (req, res) => {
    const { category, search, status, page } = req.query;
    let filtered = [...products];
    if (category) filtered = filtered.filter(p => p.category_id == category);
    if (status) filtered = filtered.filter(p => p.status === status);
    if (search) filtered = filtered.filter(p => p.name.toLowerCase().includes(search.toLowerCase()));
    const perPage = 12;
    const currentPage = parseInt(page) || 1;
    const totalPages = Math.ceil(filtered.length / perPage);
    const paged = filtered.slice((currentPage - 1) * perPage, currentPage * perPage);
    res.render('pages/products/index', {
        title: 'Products', products: paged, categories,
        totalProducts: filtered.length, currentPage, totalPages,
        query: { category, search, status }
    });
});

router.get('/create', requireAuth, (req, res) => {
    res.render('pages/products/form', { title: 'Create Product', product: null, categories, editing: false });
});

router.get('/edit/:id', requireAuth, (req, res) => {
    const product = products.find(p => p.id == req.params.id);
    if (!product) return res.redirect('/products');
    res.render('pages/products/form', { title: 'Edit Product', product, categories, editing: true });
});

router.post('/create', requireAuth, (req, res) => {
    req.flash('success', 'Product created successfully');
    res.redirect('/products');
});

router.post('/edit/:id', requireAuth, (req, res) => {
    req.flash('success', 'Product updated successfully');
    res.redirect('/products');
});

router.post('/delete/:id', requireAuth, (req, res) => {
    req.flash('success', 'Product archived successfully');
    res.redirect('/products');
});

module.exports = router;
