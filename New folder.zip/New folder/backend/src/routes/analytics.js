const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const { analyticsData } = require('../data/mockData2');

router.get('/', requireAuth, (req, res) => {
    res.render('pages/analytics/index', { title: 'Analytics', data: analyticsData });
});

module.exports = router;
