const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const { kanbanBoards, timelineMilestones, timelineAllTasks, timelineStats, timelineCategories, timelineCategoryColors } = require('../data/mockData2');

router.get('/', requireAuth, (req, res) => {
    res.render('pages/kanban/index', { title: 'Project Planning', boards: kanbanBoards, activeBoard: kanbanBoards[0] });
});

router.get('/timeline', requireAuth, (req, res) => {
    const category = req.query.category || '';
    const search = req.query.search || '';
    const view = req.query.view || 'monthly';

    let activeMilestone = timelineMilestones[0];
    if (req.query.milestone) {
        activeMilestone = timelineMilestones.find(m => m.id == req.query.milestone) || activeMilestone;
    }

    let filteredTasks = [...timelineAllTasks];
    if (category) filteredTasks = filteredTasks.filter(t => t.category === category);
    if (search) filteredTasks = filteredTasks.filter(t => t.title.toLowerCase().includes(search.toLowerCase()));

    res.render('pages/kanban/timeline', {
        title: 'Timeline',
        milestones: timelineMilestones,
        activeMilestone,
        allTasks: filteredTasks,
        stats: timelineStats,
        categories: timelineCategories,
        categoryColors: timelineCategoryColors,
        currentCategory: category,
        currentSearch: search,
        currentView: view,
        query: req.query
    });
});

router.post('/task/create', requireAuth, (req, res) => {
    req.flash('success', 'Task created');
    res.redirect('/kanban');
});

router.post('/task/:id/move', requireAuth, (req, res) => {
    req.flash('success', 'Task moved');
    res.redirect('/kanban');
});

router.post('/timeline/milestone/create', requireAuth, (req, res) => {
    req.flash('success', 'Milestone created');
    res.redirect('/kanban/timeline');
});

module.exports = router;

