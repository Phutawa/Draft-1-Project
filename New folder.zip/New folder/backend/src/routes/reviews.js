const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const { reviews } = require('../data/mockData2');

router.get('/', requireAuth, (req, res) => {
    const { rating, sort } = req.query;
    let filtered = [...reviews];
    if (rating) filtered = filtered.filter(r => r.rating == rating);
    if (sort === 'date') filtered.sort((a, b) => b.id - a.id);
    if (sort === 'rating') filtered.sort((a, b) => b.rating - a.rating);
    res.render('pages/reviews/index', { title: 'Reviews', reviews: filtered, query: { rating, sort } });
});

router.post('/:id/reply', requireAuth, (req, res) => {
    req.flash('success', 'Reply posted successfully');
    res.redirect('/reviews');
});

router.post('/:id/hide', requireAuth, (req, res) => {
    req.flash('success', 'Review hidden');
    res.redirect('/reviews');
});

router.post('/:id/delete', requireAuth, (req, res) => {
    req.flash('success', 'Review deleted');
    res.redirect('/reviews');
});

module.exports = router;
