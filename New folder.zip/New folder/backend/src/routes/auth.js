const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const { admins } = require('../data/mockData');

router.get('/login', (req, res) => {
    res.render('pages/auth/login', { layout: 'layouts/auth', title: 'Admin Login' });
});

router.post('/login', async (req, res) => {
    const { username, password } = req.body;
    // Mock login - accept any admin username with password "admin123"
    const admin = admins.find(a => a.username === username || a.email === username);
    if (admin && (password === 'admin123')) {
        req.session.user = { id: admin.id, username: admin.username, name: admin.name, role: admin.role, avatar: admin.avatar, email: admin.email };
        req.flash('success', `Welcome back, ${admin.name}!`);
        return res.redirect('/dashboard');
    }
    // Also accept demo login
    if (username === 'admin' && password === 'admin123') {
        req.session.user = { id: 1, username: 'owner_admin', name: 'Phutawan 037', role: 'Owner', avatar: 'P', email: 'owner@store.com' };
        req.flash('success', 'Welcome back, Phutawan 037!');
        return res.redirect('/dashboard');
    }
    req.flash('error', 'Invalid username or password');
    res.redirect('/auth/login');
});

router.get('/logout', (req, res) => {
    req.session.destroy();
    res.redirect('/auth/login');
});

module.exports = router;
