const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const { chats } = require('../data/mockData2');

router.get('/', requireAuth, (req, res) => {
    const chatId = req.query.id || (chats.length > 0 ? chats[0].id : null);
    const activeChat = chats.find(c => c.id == chatId) || chats[0];
    res.render('pages/chats/index', { title: 'Chats', chats, activeChat });
});

router.post('/:id/reply', requireAuth, (req, res) => {
    req.flash('success', 'Message sent');
    res.redirect(`/chats?id=${req.params.id}`);
});

router.post('/:id/close', requireAuth, (req, res) => {
    req.flash('success', 'Conversation closed');
    res.redirect('/chats');
});

module.exports = router;
