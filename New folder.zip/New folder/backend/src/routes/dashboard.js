const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const { products, categories } = require('../data/mockData');
const { analyticsData } = require('../data/mockData2');

router.get('/', requireAuth, (req, res) => {
    res.render('pages/dashboard/index', {
        title: 'Dashboard',
        stats: {
            revenue: analyticsData.revenue,
            orders: analyticsData.orders,
            productsSold: analyticsData.productsSold,
            totalProducts: products.length
        },
        topProducts: analyticsData.topProducts,
        categoryPerformance: analyticsData.categoryPerformance,
        recentActivity: analyticsData.recentActivity,
        dailyLabels: analyticsData.dailyLabels,
        dailyRevenue: analyticsData.revenue.daily
    });
});

module.exports = router;
