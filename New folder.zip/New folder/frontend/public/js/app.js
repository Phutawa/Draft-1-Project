// Sidebar toggle, chart helpers, kanban drag-and-drop
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('show');
}

// Close sidebar on overlay click (mobile)
document.addEventListener('click', function (e) {
    const sidebar = document.getElementById('sidebar');
    if (sidebar && sidebar.classList.contains('show') && !sidebar.contains(e.target) && !e.target.closest('.mobile-toggle')) {
        sidebar.classList.remove('show');
    }
});

// Auto-dismiss flash alerts
document.querySelectorAll('.flash-alert').forEach(alert => {
    setTimeout(() => {
        alert.style.opacity = '0';
        alert.style.transform = 'translateY(-10px)';
        setTimeout(() => alert.remove(), 300);
    }, 4000);
});

// Chart helper
function createChart(canvasId, config) {
    const ctx = document.getElementById(canvasId);
    if (!ctx) return null;
    return new Chart(ctx, config);
}

// Kanban Drag and Drop
function initKanban() {
    const tasks = document.querySelectorAll('.kanban-task');
    const columns = document.querySelectorAll('.kanban-cards');

    tasks.forEach(task => {
        task.setAttribute('draggable', 'true');
        task.addEventListener('dragstart', e => {
            task.classList.add('dragging');
            e.dataTransfer.setData('text/plain', task.dataset.taskId);
        });
        task.addEventListener('dragend', () => task.classList.remove('dragging'));
    });

    columns.forEach(col => {
        col.addEventListener('dragover', e => {
            e.preventDefault();
            col.style.background = 'rgba(200, 167, 125, 0.08)';
        });
        col.addEventListener('dragleave', () => {
            col.style.background = '';
        });
        col.addEventListener('drop', e => {
            e.preventDefault();
            col.style.background = '';
            const dragging = document.querySelector('.kanban-task.dragging');
            if (dragging) col.appendChild(dragging);
        });
    });
}

document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('.kanban-board')) initKanban();
});
